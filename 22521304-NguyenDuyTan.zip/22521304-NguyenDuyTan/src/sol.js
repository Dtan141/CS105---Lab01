//1. DRAWING ALGORITHM 
var canvas = document.getElementById("canvas");
var context = canvas.getContext("2d");

var width = 1230;
var height = 680;
var drawPointRbga = [0, 0, 0, 255];
var bgRbga = [240, 240, 200, 255];
var pointRbga = [0, 0, 255, 255];
var lineRgba = [0, 0, 0, 255];
var vlineRgba = [255, 0, 0, 255];

canvas.setAttribute("width", width);
canvas.setAttribute("height", height);

function Painter(context, width, height){
    this.context = context;
    this.imageData = context.createImageData(width, height);
    this.points = [];
    this.now = [-1, -1];
    this.width = width;
    this.height = height;

    this.resetCanvas = function() {
        this.context.reset()
    }

    this.getPixelIndex = function(x, y) {
        if (x < 0 || y < 0 || x >= this.width || y >= this.height)
            return -1
        return (x + y * width) << 2;
    }

    this.setPixel = function(x, y, rgba) {
        pixelIndex = this.getPixelIndex(x, y);
        if (pixelIndex == -1) return;
        for (let i = 0; i < 4; i++) {
            this.imageData.data[pixelIndex + i] = rgba[i];
        }
    }

    this.drawPoint = function(p, rgba) {
        let x = p[0]
        let y = p[1]
        for (let i = -1; i <= 1; i++)
            for (let j = -1; j <= 1; j++)
                this.setPixel(x + i, y + j, rgba);
        
        this.context.putImageData(this.imageData, 0, 0);
    }

    this.drawLineWithDDA = function(p0, p1, rgba) {
        let x0 = p0[0], y0 = p0[1];
        let x1 = p1[0], y1 = p1[1];
        dx = x1 - x0, dy = y1 - y0;
        if (dx == 0 && dy == 0)
            return;
        //Step 1: so sanh dy va dx --> ve theo x hay ve theo y
        if (Math.abs(dy) <= Math.abs(dx)) {
            //doi vi tri 2 diem neu can thiet
            if (x1 < x0) {
                let tx = x0; x0 = x1; x1 = tx;
                let ty = y0; y0 = y1; y1 = ty;
            }

            let k = dy / dx;
            let y = y0;
            for (let x = x0; x <= x1; x++) {
                this.setPixel(x, Math.floor(y + 0.5), rgba);
                this.drawPoint(x, Math.floor(y + 0.5), rgba)
                y = y + k;
            }
        }
        else {
            if (y1 < y0) {
                let tx = x0; x0 = x1; x1 = tx;
                let ty = y0; y0 = y1; y1 = ty;
            }
            let k = dx / dy;
            let x = x0
            for (let y = y0; y <= y1; y++) {
                this.setPixel(Math.floor(x + 0.5), y, rgba);
                this.drawPoint(Math.floor(x + 0.5), y, rgba)
                x = x + k;
            }
        }
    }

    this.drawLineWithBSH = function(p0, p1, rgba) {
        let x0 = p0[0], y0 = p0[1];
        let x1 = p1[0], y1 = p1[1];
        let dx = Math.abs(x1 - x0), dy = Math.abs(y1 - y0);
        let p = 2*dy - dx;
        let x = x0;
        let y = y0;

        let x_unit = 1;
        let y_unit = 1;

        if (x1 - x0 < 0) {
            x_unit = -x_unit;
        }
        if (y1 - y0 < 0) {
            y_unit = -y_unit;
        }

        if (x0 == x1) {
            while (y != y1 + 1) {
                y +=y_unit
                this.setPixel(x,y,rgba);
                this.drawPoint(x,y,rgba);
            }
        }
        else if (y0 == y1) {
            x += x_unit;
            this.setPixel(x,y,rgba);
            this.drawPoint(x,y,rgba);
        }
        else {
            this.setPixel(x,y,rgba);
            this.drawPoint(x,y,rgba);
            while (x != x1) {
                if (p < 0) {
                    p += 2*dy;
                }
                else {
                    p += 2*(dy-dx);
                    y += y_unit;
                }
                x += x_unit;
                this.setPixel(x,y,rgba);
                this.drawPoint(x,y,rgba);
            }
        }
    }
    
    this.drawCircleMidPoint = function(xc, yc, r, rgba) {
        let x = 0
        let y = r;
        let f = 1 - r;

        this.setPixel(x + xc, y + yc, rgba);
        this.drawPoint([x + xc, y + yc], rgba);

        this.setPixel(-x + xc, y + yc, rgba);
        this.drawPoint([-x + xc, y + yc], rgba);

        this.setPixel(x + xc, -y + yc, rgba);
        this.drawPoint([x + xc, -y + yc], rgba);

        this.setPixel(-x + xc, -y + yc, rgba);
        this.drawPoint([-x + xc, -y + yc], rgba);

        this.setPixel(y + xc, x + yc, rgba);
        this.drawPoint([y + xc, x + yc], rgba);
        
        this.setPixel(-y + xc, x + yc, rgba);
        this.drawPoint([-y + xc, x + yc], rgba);

        this.setPixel(y + xc, -x + yc, rgba);
        this.drawPoint([y + xc, -x + yc], rgba);

        this.setPixel(-y + xc, -x + yc, rgba);
        this.drawPoint([-y + xc, -x + yc], rgba);

        while (x < y) {
            if (f < 0) {
                f += (x << 1) + 3;
            }
            else {
                y--;
                f += ((x - y) << 1) + 5;
            }
            x ++;
            this.setPixel(x + xc, y + yc, rgba);
            this.drawPoint([x + xc, y + yc], rgba);

            this.setPixel(-x + xc, y + yc, rgba);
            this.drawPoint([-x + xc, y + yc], rgba);

            this.setPixel(x + xc, -y + yc, rgba);
            this.drawPoint([x + xc, -y + yc], rgba);

            this.setPixel(-x + xc, -y + yc, rgba);
            this.drawPoint([-x + xc, -y + yc], rgba);

            this.setPixel(y + xc, x + yc, rgba);
            this.drawPoint([y + xc, x + yc], rgba);

            this.setPixel(-y + xc, x + yc, rgba);
            this.drawPoint([-y + xc, x + yc], rgba);

            this.setPixel(y + xc, -x + yc, rgba);
            this.drawPoint([y + xc, -x + yc], rgba);

            this.setPixel(-y + xc, -x + yc, rgba);
            this.drawPoint([-y + xc, -x + yc], rgba);
        }
    }
}

//2. CONTROL
let cursor_mode = 0 //var for checking if cursor_mode is on or off
$('#enterPosition').on('click', function() {
    //cursor mode is off, now using enter-from-keyboard mode
    cursor_mode = 0;

    $('#submitbtn').on('click', function() {
        let x0 = parseInt($('#X0').val())
        let y0 = parseInt($('#Y0').val())
        let x1 = parseInt($('#X1').val())
        let y1 = parseInt($('#Y1').val())
    
        let painter = new Painter(context, width, height)
        painter.resetCanvas()
        if ($('#dda').prop('checked')) {
            if (x0 >= 0 && y0 >= 0 && x1 >= 0 && y1 >= 0) {
                painter.drawLineWithDDA([x0, y0], [x1, y1], lineRgba)
            }
            else {
                alert('ERROR VALUE!')
            }
        }
        else if ($('#bresenham').prop('checked')) {
            if (x0 >= 0 && y0 >= 0 && x1 >= 0 && y1 >= 0) {
                painter.drawLineWithBSH([x0, y0], [x1, y1], lineRgba)
            }
            else {
                alert('ERROR VALUE!')
            }
        }
        else if ($('#midpoint').prop('checked')) {
            let x3 = parseInt($('#X3').val())
            let y3 = parseInt($('#Y3').val())
            let r = parseInt($('#r').val())
            if (x3 >= 0 && y3 >= 0 && r >= 0) {
                painter.drawPoint([x3, y3], lineRgba)
                painter.drawCircleMidPoint(x3, y3, r, lineRgba)
            }
            else {
                alert('ERROR VALUE!')
            }
        }
    })
})

$('#direct').on('click', function() {
    //cursor mode is on
    cursor_mode = 1

    let count = 0;
    let firstX;
    let firstY;
    let secondX;
    let secondY;
    // Add a click event listener to the canvas
    canvas.addEventListener("click", function(event) {
        if (cursor_mode == 1) {
            // Get the coordinates of the click relative to the canvas
            var rect = canvas.getBoundingClientRect();
            var x = Math.round(event.clientX - rect.left);
            var y = Math.round(event.clientY - rect.top);
            if (count == 0) {
                firstX = x;
                firstY = y;
                count += 1;
                let painter = new Painter(context,width,height);
                painter.setPixel(firstX, firstY, drawPointRbga);
                painter.drawPoint([firstX, firstY], drawPointRbga);
            }
            else {
                count +=1
                secondX = x;
                secondY = y;
            }
            if (count == 2) {
                count = 0;
                console.log(firstX, ' - ', firstY)
                console.log(secondX, ' -- ', secondY)
                let painter = new Painter(context,width,height);
                
                if ($('#dda').prop('checked')) {
                    painter.drawLineWithDDA([firstX, firstY], [secondX, secondY], lineRgba);
                }
                else if ($('#bresenham').prop('checked')) {
                    painter.drawLineWithBSH([firstX, firstY], [secondX, secondY], lineRgba);
                }
                else if ($('#midpoint').prop('checked')) {
                    var radius  = Math.sqrt(Math.pow(firstX - secondX, 2) + Math.pow(firstY - secondY, 2));
                    painter.drawPoint([firstX, firstY], lineRgba)
                    painter.drawCircleMidPoint(firstX, firstY, Math.round(radius), lineRgba);
                }
            }
        }
    })
})

//3. ALLOW AND DISABLE
$('#enterPosition').on('click', function() {
    $('#submitbtn').prop('disabled', false);  //Allow enter button
})

$('#direct').on('click', function() {
    //disable coordinates input and submit button
    $('#X0').prop('disabled', true)
    $('.col-6.mb-1').prop('disabled', true)
    $('#Y0').prop('disabled', true)
    $('.col-6.mb-1').prop('disabled', true)

    $('#X1').prop('disabled', true); 
    $('.col-6.mb-1').prop('disabled', true);
    $('#Y1').prop('disabled', true); 
    $('.col-6.mb-1').prop('disabled', true);

    $('#X3').prop('disabled', true);
    $('.col-6.mb-1').prop('disabled', true);
    $('#Y3').prop('disabled', true);
    $('.col-6.mb-1').prop('disabled', true);
    $('#r').prop('disabled', true);
    $('.col-6.mb-1').prop('disabled', true);

    $('#submitbtn').prop('disabled', true);
})

$('#dda').on('click', function() {  //Allow drawing line input, disable drawing circle input
    if(!cursor_mode) {
        $('#X0').prop('disabled', false); 
        $('.col-6.mb-1').prop('disabled', false); 
        $('#Y0').prop('disabled', false); 
        $('.col-6.mb-1').prop('disabled', false);

        $('#X1').prop('disabled', false); 
        $('.col-6.mb-1').prop('disabled', false);
        $('#Y1').prop('disabled', false); 
        $('.col-6.mb-1').prop('disabled', false);

        $('#X3').prop('disabled', true);
        $('.col-6.mb-1').prop('disabled', true);
        $('#Y3').prop('disabled', true);
        $('.col-6.mb-1').prop('disabled', true);
        $('#r').prop('disabled', true);
        $('.col-6.mb-1').prop('disabled', true);
    }
});

$('#bresenham').on('click', function() {  //Allow drawing line input, disable drawing circle input
    if(!cursor_mode) {
        $('#X0').prop('disabled', false); 
        $('.col-6.mb-1').prop('disabled', false); 
        $('#Y0').prop('disabled', false); 
        $('.col-6.mb-1').prop('disabled', false);

        $('#X1').prop('disabled', false); 
        $('.col-6.mb-1').prop('disabled', false);
        $('#Y1').prop('disabled', false); 
        $('.col-6.mb-1').prop('disabled', false);

        $('#X3').prop('disabled', true);
        $('.col-6.mb-1').prop('disabled', true);
        $('#Y3').prop('disabled', true);
        $('.col-6.mb-1').prop('disabled', true);
        $('#r').prop('disabled', true);
        $('.col-6.mb-1').prop('disabled', true);
    }
})

$('#midpoint').on('click', function() {  //Allow drawing circle input, disable drawing line input
    if (!cursor_mode) {
        $('#X0').prop('disabled', true); 
        $('.col-6.mb-1').prop('disabled', true); 
        $('#Y0').prop('disabled', true); 
        $('.col-6.mb-1').prop('disabled', true);
    
        $('#X1').prop('disabled', true); 
        $('.col-6.mb-1').prop('disabled', true);
        $('#Y1').prop('disabled', true); 
        $('.col-6.mb-1').prop('disabled', true);
    
        $('#X3').prop('disabled', false);
        $('.col-6.mb-1').prop('disabled', false);
        $('#Y3').prop('disabled', false);
        $('.col-6.mb-1').prop('disabled', false);
        $('#r').prop('disabled', false);
        $('.col-6.mb-1').prop('disabled', false);
    }
})
